


#include <iostream>

int main () {
  int numero1 {0};
  int numero2 {0};
  std::cout << "Introduzca un numero: " << std::endl;
  std::cin >> numero1;
  std::cout << "Introduzca otro numero: " << std::endl;
  std::cin >> numero2;
  std::cout << numero1 << "+" << numero2 << "=" << numero1 + numero2 <<
std::endl;
  std::cout << numero1 << "-" << numero2 << "=" << numero1 - numero2 <<
std::endl;
  std::cout << numero1 << "*" << numero2 << "=" << numero1 * numero2 <<
std::endl;
  std::cout << numero1 << "/" << numero2 << "=" << numero1 / numero2 <<
std::endl;
  std::cout << numero1 << "%" << numero2 << "=" << numero1 % numero2 <<
std::endl;
  std::cout << numero1 << ">" << numero2 << ":" << (numero1 > numero2) <<
std::endl;
  std::cout << numero1 << ">=" << numero2 << ":" << (numero1 >= numero2) <<
std::endl;
  std::cout << numero1 << "<" << numero2 << ":" << (numero1 < numero2) <<
std::endl;
  std::cout << numero1 << "<=" << numero2 << ":" << (numero1 <= numero2) <<
std::endl;
  std::cout << numero1 << "!=" << numero2 << ":" << (numero1 != numero2) <<
std::endl;
  std::cout << "Nota: En operadores logicos: 0=False, 1=True" << std::endl;
  return 0;
}


