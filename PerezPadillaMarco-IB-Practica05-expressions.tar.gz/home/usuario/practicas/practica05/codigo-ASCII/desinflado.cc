


 #include <iostream>

 int main () {
  char mayuscula {'a'};
  std::cout << "Introduzca una letra en mayusculas: " << std::endl;
  std ::cin >> mayuscula;
  int post_mayuscula = static_cast <int> (mayuscula);
  int pre_minuscula = post_mayuscula + 32;
  char minuscula = static_cast <char> (pre_minuscula);
  std::cout << mayuscula << " " << minuscula << std::endl;
  return 0;
}
