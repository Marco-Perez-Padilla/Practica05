


#include <iostream>

int main () {
  int a {0};
  int b {0};
  std::cout << "Introduzca el dividendo: " << std::endl;
  std::cin >> a;
  std::cout << "Introduzca el divisor: " << std::endl;
  std::cin >> b;
  if (a >= 0 && b > 0) {
    std::cout << (int {a/b}) << " " << (a%b) << std::endl;
  }
  else {
    std::cout << "Revise que: Divisor > 0  y que: Dividendo >= 0 ";
  }
  return 0;
} 
